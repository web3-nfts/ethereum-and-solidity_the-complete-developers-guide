import React from "react";

export default () => {
  return <h1>Welcome to the show page!!!</h1>;
};
