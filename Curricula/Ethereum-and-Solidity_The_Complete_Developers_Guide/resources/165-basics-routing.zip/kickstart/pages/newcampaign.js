import React from "react";

export default () => {
  return <h1>This is a new campaign page!!!</h1>;
};
